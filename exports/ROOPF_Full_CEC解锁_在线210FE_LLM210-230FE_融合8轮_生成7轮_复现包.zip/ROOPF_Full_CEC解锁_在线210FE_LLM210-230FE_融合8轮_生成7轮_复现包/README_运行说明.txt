ROOPF Full 可复现运行包：CEC 解锁、在线 210 FE、LLM 210/230 FE、融合8轮、下一轮起生成7轮

一、内容与适用范围
本包运行已核验的 R19 Full 分支：D10、初始种群100、总预算300 FE（含初始100）、每函数100轨迹（10批×10条），35函数（BBOB24、CEC-style6、UAV5）。包含冻结 Anchor 与 Residual 权重、S01_L08 464条检索案例及其覆盖半径、CEC解锁策略、修复后的API输出契约、BBOB偏移、UAV目标定义和350批配对初始种群及随机状态。无历史实验结果、目标函数缓存、API响应日志或密钥；不包含三项消融、论文对照算法及其结果。无需训练即可运行 Full。训练环境、离线案例重建所用完整训练日志和训练任务不在此包中。

二、运行
Linux / WSL2 的 ooneurgo 环境：
  conda activate ooneurgo
  python -u run_final.py --check
  python -u run_final.py --benchmark all --workers 24 --device cuda --progress-seconds 10
可选 --benchmark bbob、cec、uav；--device cpu 使用CPU代理，但计算数值可能不同。实时显示JSON进度并写入 outputs/时间/；Full 全35函数预计700次真实API请求。--check 不调用 API，不替代全量验证。

三、密钥与网络
按单行格式将密钥放入 ~/.config/roopf_agent/worldcodes.env：
  WORLDCODES_API_KEY=自己的密钥
密钥不包含在包里。默认使用 https://worldcodes.online/v1/chat/completions、deepseek-v4-flash 和 http://127.0.0.1:7890；代理可通过 --api-proxy 修改，空字符串表示不用代理。修改模型、端点或后端属于新的运行条件。API调用可能收费。失败时使用 matched38 回退，不自动重试。完成状态需全部函数有有效执行返回。

四、数据与数值说明
350份配对初始种群及 RNG 状态是运行输入，不含任何历史目标值、旧决策或 API 响应；BBOB20 保持10条轨迹的批次语义。实时LLM响应和计算后端可能产生不同动作与最终数值，不能保证历史结果逐位一致。案例库在离线训练函数上为完整架构采集；不会在线训练或重建。历史对照、消融和配对轨迹结果不包含在包内。

五、新环境
Python 3.10；torch 2.11.0+cu128、numpy 2.2.6、sympy 1.14.0；参考 requirements.txt。CUDA运行需要兼容的NVIDIA驱动。当前代码依赖 fcntl 和 Unix socket，使用 Linux/WSL2。
