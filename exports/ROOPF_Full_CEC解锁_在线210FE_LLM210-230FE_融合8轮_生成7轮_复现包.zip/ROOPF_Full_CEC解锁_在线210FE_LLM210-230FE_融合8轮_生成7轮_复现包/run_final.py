#!/usr/bin/env python3
"""Portable Full runtime for the frozen CEC-unlocked release; no historical results."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import multiprocessing as mp
import os
from pathlib import Path
import secrets
import sys
import tempfile
import time
import traceback

ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT),str(ROOT/'scripts')]
for key in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):
    os.environ[key]='1'
sys.dont_write_bytecode=True
SETTINGS=None
OUTPUT=None
PROXY=None


def read(path):return json.loads(Path(path).read_text())
def write(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    pending=path.with_suffix(path.suffix+'.writing')
    pending.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    pending.replace(path)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def emit(event,**value):print(json.dumps(dict(event=event,**value),ensure_ascii=False),flush=True)


def initialize(settings,output,address=None,authkey=None):
    global SETTINGS,OUTPUT,PROXY
    os.environ['CUDA_VISIBLE_DEVICES']=''
    import torch
    torch.set_num_threads(1)
    SETTINGS=settings;OUTPUT=Path(output)
    from roopf.cec_uniform import install_execution_policy
    policy=install_execution_policy()
    assert policy['policy_id']==settings['execution_policy']
    if address is not None:
        from hardware_backend import ProxyClient
        PROXY=ProxyClient(address,authkey)


def problem_for(group,fid):
    # Keep the measured objective wrappers, bounds, offsets and UAV name semantics.
    import run_roopf as problems
    if group=='BBOB':
        fun=dict(problems.BBOB_FUNCTIONS[fid],xlb=-5,xub=5)
        problems.setOffset(fun,problems.load_bbob_offsets(ROOT/'data/bbob_offsets_d10.pkl')[fid])
        return problems.BBOBProblem(fun,10)
    if group=='CEC-style':
        fun=dict(problems.CEC_FUNCTIONS[f'cecf{fid}'])
        fun.update(xlb=fun.get('xlb',-100),xub=fun.get('xub',100))
        return problems.CECStyleProblem(fun,10)
    module=sys.modules.get('runtime_uav')
    if module is None:
        spec=importlib.util.spec_from_file_location('runtime_uav',ROOT/'assets/uav_benchmark.py')
        module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    p=problems.BBOBProblem(dict(fid=f'uav{fid}',xlb=-5,xub=5),10)
    p.calfitness=lambda x:module.uav_objective(x,module.SCENARIOS[fid-1])
    return p


def build_model(group,fid,batch,mode='llm'):
    import run_roopf as builder
    from types import SimpleNamespace
    from roopf.scheduled_evidence_agent_r18 import ScheduledEvidenceAgent
    builder.set_seed(20260630)  # Match R19 model construction before loading paired RNG.
    model=builder.build_optimizer(SimpleNamespace(dimension=10,population_size=100,budget=300,agentic_mode='off'))
    agent=ScheduledEvidenceAgent(ROOT/'assets/offline_memory.json',OUTPUT/'api_journal',schedule=read(ROOT/'config/schedule.json'),mode=mode,arm='joint',
        budget=dict(used=0,limit=700),api_config=SETTINGS['api'])
    agent.execution_context=dict(round='r19_s01l08_component_ablations',group=group,fid=fid,batch=batch,arm='llm_full',
        online_admission_start_fe=210,llm_decision_fe=[210,230],schedule_signature=read(ROOT/'config/schedule.json'),memory_sha256=agent.memory_hash)
    model.fusion_agent=agent
    if PROXY is not None:
        proxy=model.surrogate
        proxy.predict=lambda ax,ay,c,p,distance_scale=.15:PROXY.predict(proxy,ax,ay,c,p,distance_scale)
    return model,agent


def batch_run(task,mode='llm'):
    import numpy as np
    import torch
    group,fid,batch=task
    folder=OUTPUT/'batches'/f'{group}_f{fid:02d}'/f'b{batch:02d}'
    folder.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();model,agent=build_model(group,fid,batch,mode)
    p=problem_for(group,fid)
    assert not __import__('roopf.model',fromlist=['_is_structured_system_problem'])._is_structured_system_problem(p)
    index={'BBOB':0,'CEC-style':24,'UAV':30}[group]+fid-1
    seed=int(SETTINGS['seed'])+index*1000+batch
    # Paired initial populations and RNG states: no prior objective results or API responses.
    np.random.seed(seed);torch.manual_seed(seed)
    fixture_path=ROOT/'paired_initials'/f'{group}_f{fid:02d}'/f'b{batch:02d}.npz'
    with np.load(fixture_path,allow_pickle=False) as fixture:
        population=torch.from_numpy(fixture['population'].copy())
        torch.set_rng_state(torch.from_numpy(fixture['rng'].copy()))
        original_after=torch.from_numpy(fixture['original_after'].copy())
    agent.execution_context.update(paired_initial_sha256=hashlib.sha256(population.numpy().tobytes()).hexdigest(),
        paired_solver_rng_sha256=hashlib.sha256(torch.get_rng_state().numpy().tobytes()).hexdigest())
    values=[];decisions=[]
    agent.active_record=decisions.append
    class Counted:
        def __init__(self):self.nfe=0;self.last=0
        def __getattr__(self,name):return getattr(p,name)
        def calfitness(self,x):
            y=p.calfitness(x).reshape(x.shape[:2]);values.append(y.detach().cpu())
            self.nfe+=x.shape[1]
            if time.monotonic()-self.last>2 or self.nfe>=300:
                write(folder/'progress.json',dict(status='running',nfe_per_trajectory=self.nfe,trajectories=10,
                    api=agent.stats,elapsed_seconds=time.monotonic()-started))
                self.last=time.monotonic()
            return y
    counted=Counted()
    with torch.no_grad():_,trail,nfe,points=model(population,counted)
    evaluated=torch.cat(values,1).numpy();final=evaluated.min(1)
    assert nfe==counted.nfe==300 and evaluated.shape==(10,300) and np.isfinite(evaluated).all()
    assert np.array_equal(final,trail[:,-1].numpy())
    assert torch.equal(torch.get_rng_state(),original_after),'Final RNG state differs from paired original'
    assert len(decisions)==45
    assert [r['step'] for r in decisions if r['request_event']]==([0,10] if mode=='llm' else [])
    assert all(c['candidate_count']==38 for r in decisions for c in r['current'])
    if mode=='llm':
        assert agent.stats['requests']==2 and agent.stats['api_reused']==0
        if agent.resource_exhausted or agent.uncertain_api_outcome:raise RuntimeError('API incomplete or uncertain; inspect journal')
        from roopf.current_evidence_agent import request_context_digest
        for decision in decisions:
            if decision['request_event']:
                journal=read(OUTPUT/'api_journal'/(decision['api_request_sha256']+'.json'))
                assert journal['config_ids']==decision['configs']
                assert journal['decision_context_sha256']==request_context_digest(decision['api_trajectories'],decision['execution_context'])
                assert decision['api_row_validation']['valid_trajectory_ids']==journal['valid_trajectory_ids']
    np.savez_compressed(folder/'values.npz',values=evaluated,final_values=final,executed_points=points.numpy())
    import gzip
    with gzip.open(folder/'decisions.json.gz','wt') as stream:json.dump(decisions,stream,allow_nan=False)
    receipt=dict(group=group,fid=fid,batch=batch,seed=seed,trajectories=10,nfe_per_trajectory=300,
        native_fe=3000,cached_fe=0,final_values=final.tolist(),mean=float(final.mean()),population_std=float(final.std(ddof=0)),
        variance=float(final.var(ddof=0)),api=agent.stats,elapsed_seconds=time.monotonic()-started,status='complete',
        validation_kind='live_llm' if mode=='llm' else 'engineering_only_no_api')
    write(folder/'COMPLETE.json',receipt)
    return receipt


def check_files():
    manifest=read(ROOT/'RUNTIME_MANIFEST.json')
    for path,expected in manifest['files'].items():
        assert sha(ROOT/path)==expected,path
    initialize(read(ROOT/'config/final.json'),ROOT/'outputs/unused_check_path')
    import torch
    model,_=build_model('CEC-style',1,0,mode='collect')
    # The Agent journal constructor creates a directory; remove only its empty check directories.
    (OUTPUT/'api_journal').rmdir();OUTPUT.rmdir()
    parent=ROOT/'outputs'
    if parent.exists() and not any(parent.iterdir()):parent.rmdir()
    for group,count in [('BBOB',24),('CEC-style',6),('UAV',5)]:
        for fid in range(1,count+1):
            p=problem_for(group,fid)
            assert not __import__('roopf.model',fromlist=['_is_structured_system_problem'])._is_structured_system_problem(p)
            y=p.calfitness(p.genRandomPop((10,100,10)))
            assert y.shape==(10,100) and torch.isfinite(y).all()
    emit('runtime_check_passed',files=len(manifest['files']),functions=35,anchor_loaded=model.baseline_model is not None,
        residual_loaded=model.router_model is not None,cases=len(model.fusion_agent.cases),cec_unlocked=True,new_api_requests=0)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--benchmark',choices=['all','bbob','cec','uav'],default='all')
    parser.add_argument('--workers',type=int,default=None)
    parser.add_argument('--device',choices=['cuda','cpu'],default='cuda')
    parser.add_argument('--api-proxy',default=None)
    parser.add_argument('--progress-seconds',type=float,default=10)
    parser.add_argument('--output-dir',type=Path,default=None)
    parser.add_argument('--check',action='store_true',help='Check code, weights, cases and 35 objectives; sends no API request')
    args=parser.parse_args()
    if args.check:check_files();return
    settings=read(ROOT/'config/final.json')
    workers=settings['hardware']['workers'] if args.workers is None else args.workers
    if not 1<=workers<=24:parser.error('--workers must be between 1 and 24')
    if args.progress_seconds<=0:parser.error('--progress-seconds must be positive')
    if args.api_proxy is not None:settings['api']['proxy']=args.api_proxy
    credential=Path.home()/'.config/roopf_agent/worldcodes.env'
    if not credential.is_file() or not credential.read_text().strip().startswith('WORLDCODES_API_KEY='):
        raise RuntimeError('请先配置 ~/.config/roopf_agent/worldcodes.env 中的 WORLDCODES_API_KEY')
    output=(args.output_dir or ROOT/'outputs'/time.strftime('%Y%m%d_%H%M%S')).resolve()
    output.mkdir(parents=True,exist_ok=False)
    selected={'all':['BBOB','CEC-style','UAV'],'bbob':['BBOB'],'cec':['CEC-style'],'uav':['UAV']}[args.benchmark]
    count={'BBOB':24,'CEC-style':6,'UAV':5}
    tasks=[(g,f,b) for b in range(10) for g in selected for f in range(1,count[g]+1)]
    write(output/'RUN_CONFIG.json',dict(settings=settings,device=args.device,workers=workers,groups=selected,
        trajectories_per_function=100,expected_api_requests=2*len(tasks),fresh_initials=False,paired_initials=True,
        source_manifest_sha256=sha(ROOT/'RUNTIME_MANIFEST.json')))
    from hardware_backend import serve
    ctx=mp.get_context('spawn');gpu=None;started=time.monotonic();receipts=[];last=started
    emit('start',output=str(output),functions=sum(count[g] for g in selected),trajectories=len(tasks)*10,
        batches=len(tasks),workers=workers,device=args.device,expected_api_requests=2*len(tasks))
    temp_context=tempfile.TemporaryDirectory(prefix='roopf_final_');tmp=temp_context.name
    try:
        address=str(Path(tmp)/'cuda.sock');authkey=secrets.token_bytes(32)
        if args.device=='cuda':
            ready,child=ctx.Pipe(duplex=False)
            gpu=ctx.Process(target=serve,args=(address,authkey,settings['hardware']['visible_devices'],child,
                str(output/'GPU_RUNTIME.json'),settings['hardware']['gpu_concurrency']))
            gpu.start();child.close()
            if not ready.poll(60):raise RuntimeError('CUDA initialization timed out')
            info=ready.recv();ready.close()
            if info['status']!='ready':raise RuntimeError(str(info))
            emit('gpu_ready',**info)
        else:address=authkey=None
        with ctx.Pool(workers,initializer=initialize,initargs=(settings,str(output),address,authkey)) as pool:
            pending=pool.imap_unordered(batch_run,tasks,chunksize=1)
            while len(receipts)<len(tasks):
                try:
                    receipt=pending.next(timeout=1);receipts.append(receipt)
                    emit('batch_complete',group=receipt['group'],fid=receipt['fid'],batch=receipt['batch'],
                        completed=len(receipts),total=len(tasks),api=receipt['api'])
                except mp.TimeoutError:pass
                now=time.monotonic()
                if now-last>=args.progress_seconds:
                    elapsed=now-started;eta=elapsed*(len(tasks)-len(receipts))/len(receipts) if receipts else None
                    progress=dict(completed_batches=len(receipts),total_batches=len(tasks),
                        completed_trajectories=len(receipts)*10,elapsed_seconds=round(elapsed,1),
                        estimated_remaining_seconds=round(eta,1) if eta is not None else None)
                    journal_rows=[read(p) for p in (output/'api_journal').glob('*.json')]
                    status_counts={state:sum(row['status']==state for row in journal_rows) for state in ('ok','partial','failed','pending')}
                    progress['api_status']=status_counts
                    write(output/'PROGRESS.json',progress);emit('progress',**progress);last=now
                    finished=status_counts['ok']+status_counts['partial']+status_counts['failed']
                    if finished>=100 and (status_counts['ok']+status_counts['partial'])/finished<0.2:
                        raise RuntimeError('API valid response rate below 20% over at least 100 completed requests; stopping with records preserved')
        import numpy as np
        stats=[]
        for g in selected:
            for fid in range(1,count[g]+1):
                rows=[r for r in receipts if r['group']==g and r['fid']==fid]
                values=np.array([v for r in sorted(rows,key=lambda x:x['batch']) for v in r['final_values']])
                assert values.shape==(100,)
                stats.append(dict(group=g,fid=fid,mean=float(values.mean()),population_std=float(values.std(ddof=0)),variance=float(values.var(ddof=0))))
        api_rows=[read(f) for f in (output/'api_journal').glob('*.json')]
        usage=[r.get('response',{}).get('usage',{}) for r in api_rows]
        credit=[u['credit'] for u in usage if isinstance(u.get('credit'),(int,float))]
        audit=dict(attempts=len(api_rows),statuses={s:sum(r['status']==s for r in api_rows) for s in ['ok','partial','failed','pending']},
            prompt_tokens=sum(u.get('prompt_tokens',0) for u in usage),completion_tokens=sum(u.get('completion_tokens',0) for u in usage),
            provider_credit_units=sum(credit),responses_with_credit=len(credit),currency_inferred=False)
        assert audit['attempts']==2*len(tasks)
        coverage={(g,f):0 for g in selected for f in range(1,count[g]+1)}
        for entry in api_rows:
            context=entry['execution_context'];coverage[(context['group'],context['fid'])]+=len(entry.get('valid_trajectory_ids',[]))
        complete=all(v>0 for v in coverage.values()) and audit['statuses']['pending']==0
        result=dict(status='complete_live_api_coverage_verified' if complete else 'complete_trajectories_api_coverage_incomplete',functions=stats,api=audit,valid_decision_rows_by_function={f'{g}:{f}':v for (g,f),v in coverage.items()},native_fe=len(tasks)*3000,cached_fe=0,
            elapsed_seconds=time.monotonic()-started)
        write(output/'FINAL_RESULT.json',result);emit('complete',output=str(output),validation_status=result['status'],**audit)
    except BaseException:
        write(output/'FAILURE.json',dict(status='partial_or_failed',completed_batches=len(receipts),traceback=traceback.format_exc()));raise
    finally:
        if gpu is not None:
            if gpu.is_alive():
                from multiprocessing.connection import Client
                try:
                    with Client(address,family='AF_UNIX',authkey=authkey) as c:c.send({'op':'shutdown'})
                except OSError:pass
            gpu.join(timeout=5)
            if gpu.is_alive():gpu.terminate();gpu.join(timeout=5)
        temp_context.cleanup()

if __name__=='__main__':main()
